from pyecore.resources import ResourceSet, URI
from pyecore.valuecontainer import BadValueError
from pyecore.ecore import EString,EClass
import csv
import argparse
import json
from web3 import Web3
from assertpy import assert_that
import sys

# Create the parser
my_parser = argparse.ArgumentParser(description='Load emf data into an ethereum blockchain')

# Add the arguments
my_parser.add_argument('source_meta_model',
                       metavar='source_meta_model',
                       type=str,
                       help='the path to the source meta-model')


my_parser.add_argument('source_model',
                       metavar='source_model',
                       type=str,
                       help='the path to the source model which conforms to the source meta-model')


# Execute the parse_args() method
args = my_parser.parse_args()
source_meta_model = args.source_meta_model
source_model = args.source_model


# Set up web3 connection with Ganache
ganache_url = "http://127.0.0.1:7545"
web3 = Web3(Web3.HTTPProvider(ganache_url))

num_contracts = 4
abis = []
bytecodes = []
contract_names = []

contract_names.append('MovieDataSet')
abis.append(json.loads('[{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"movies","outputs":[{"internalType":"contractMovie","name":"","type":"address"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"persons","outputs":[{"internalType":"contractPerson","name":"","type":"address"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"roles","outputs":[{"internalType":"contractRole","name":"","type":"address"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"getPersons","outputs":[{"internalType":"contractPerson[]","name":"","type":"address[]"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"contractPerson","name":"aPerson","type":"address"}],"name":"addPerson","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"getMovies","outputs":[{"internalType":"contractMovie[]","name":"","type":"address[]"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"contractMovie","name":"aMovie","type":"address"}],"name":"addMovie","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"getRoles","outputs":[{"internalType":"contractRole[]","name":"","type":"address[]"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"contractRole","name":"aRole","type":"address"}],"name":"addRole","outputs":[],"stateMutability":"nonpayable","type":"function"}]'))
bytecodes.append("0x608060405234801561001057600080fd5b50610479806100206000396000f3fe608060405234801561001057600080fd5b50600436106100935760003560e01c80634c6b6c6f116100665780634c6b6c6f146101a257806371061398146101aa578063a2f9eac6146101b2578063bc672a38146101c5578063bfda4a491461022257600080fd5b80632c53b406146100985780633deda6d3146100b65780633f877f7214610117578063404ebf6c14610177575b600080fd5b6100a0610235565b6040516100ad91906103a1565b60405180910390f35b6101156100c4366004610406565b6001805480820182556000919091527fb10e2d527612073b26eecdfd717e6a320cf44b4afac2b0732d9fcbe2b7fa0cf60180546001600160a01b0319166001600160a01b0392909216919091179055565b005b610115610125366004610406565b600280546001810182556000919091527f405787fa12a823e0f2b7631cc41b3ba8828b3321ca811111fa75cd3aa3bb5ace0180546001600160a01b0319166001600160a01b0392909216919091179055565b61018a61018536600461042a565b610297565b6040516001600160a01b0390911681526020016100ad565b6100a06102c1565b6100a0610321565b61018a6101c036600461042a565b610381565b6101156101d3366004610406565b600080546001810182559080527f290decd9548b62a8d60345a988386fc84ba6bc95484008f6362f93160ef3e5630180546001600160a01b0319166001600160a01b0392909216919091179055565b61018a61023036600461042a565b610391565b6060600180548060200260200160405190810160405280929190818152602001828054801561028d57602002820191906000526020600020905b81546001600160a01b0316815260019091019060200180831161026f575b5050505050905090565b600181815481106102a757600080fd5b6000918252602090912001546001600160a01b0316905081565b6060600080548060200260200160405190810160405280929190818152602001828054801561028d576020028201919060005260206000209081546001600160a01b0316815260019091019060200180831161026f575050505050905090565b6060600280548060200260200160405190810160405280929190818152602001828054801561028d576020028201919060005260206000209081546001600160a01b0316815260019091019060200180831161026f575050505050905090565b600081815481106102a757600080fd5b600281815481106102a757600080fd5b6020808252825182820181905260009190848201906040850190845b818110156103e25783516001600160a01b0316835292840192918401916001016103bd565b50909695505050505050565b6001600160a01b038116811461040357600080fd5b50565b60006020828403121561041857600080fd5b8135610423816103ee565b9392505050565b60006020828403121561043c57600080fd5b503591905056fea2646970667358221220ee6e456783016658a02e09b191c8b23bc7d061d5b09209eccdfc9dde28020f7864736f6c634300080c0033")


contract_names.append('Person')
abis.append(json.loads('[{"inputs":[],"name":"id","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"getId","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"uint256","name":"aId","type":"uint256"}],"name":"setId","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"getName","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"string","name":"aName","type":"string"}],"name":"setName","outputs":[],"stateMutability":"nonpayable","type":"function"}]'))
bytecodes.append("0x608060405234801561001057600080fd5b50610446806100206000396000f3fe608060405234801561001057600080fd5b50600436106100625760003560e01c806306fdde031461006757806317d7de7c146100855780635d1ca6311461008d578063af640d0f1461009f578063c47f0027146100a8578063d0e0ba95146100bd575b600080fd5b61006f6100d0565b60405161007c91906102a0565b60405180910390f35b61006f61015e565b6000545b60405190815260200161007c565b61009160005481565b6100bb6100b636600461030b565b6101f0565b005b6100bb6100cb3660046103bc565b600055565b600180546100dd906103d5565b80601f0160208091040260200160405190810160405280929190818152602001828054610109906103d5565b80156101565780601f1061012b57610100808354040283529160200191610156565b820191906000526020600020905b81548152906001019060200180831161013957829003601f168201915b505050505081565b60606001805461016d906103d5565b80601f0160208091040260200160405190810160405280929190818152602001828054610199906103d5565b80156101e65780601f106101bb576101008083540402835291602001916101e6565b820191906000526020600020905b8154815290600101906020018083116101c957829003601f168201915b5050505050905090565b8051610203906001906020840190610207565b5050565b828054610213906103d5565b90600052602060002090601f016020900481019282610235576000855561027b565b82601f1061024e57805160ff191683800117855561027b565b8280016001018555821561027b579182015b8281111561027b578251825591602001919060010190610260565b5061028792915061028b565b5090565b5b80821115610287576000815560010161028c565b600060208083528351808285015260005b818110156102cd578581018301518582016040015282016102b1565b818111156102df576000604083870101525b50601f01601f1916929092016040019392505050565b634e487b7160e01b600052604160045260246000fd5b60006020828403121561031d57600080fd5b813567ffffffffffffffff8082111561033557600080fd5b818401915084601f83011261034957600080fd5b81358181111561035b5761035b6102f5565b604051601f8201601f19908116603f01168101908382118183101715610383576103836102f5565b8160405282815287602084870101111561039c57600080fd5b826020860160208301376000928101602001929092525095945050505050565b6000602082840312156103ce57600080fd5b5035919050565b600181811c908216806103e957607f821691505b6020821081141561040a57634e487b7160e01b600052602260045260246000fd5b5091905056fea26469706673582212202dc8df47075a5c7a9e75cddc86ace18ab66f07091b18dda280f077869d4d337464736f6c634300080c0033")

contract_names.append('Movie')
abis.append(json.loads('[{"inputs":[],"name":"country","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"id","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"title","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"year","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"getId","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"uint256","name":"aId","type":"uint256"}],"name":"setId","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"getTitle","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"string","name":"aTitle","type":"string"}],"name":"setTitle","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"getCountry","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"string","name":"aCountry","type":"string"}],"name":"setCountry","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"getYear","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"uint256","name":"aYear","type":"uint256"}],"name":"setYear","outputs":[],"stateMutability":"nonpayable","type":"function"}]'))
bytecodes.append("0x608060405234801561001057600080fd5b5061050e806100206000396000f3fe608060405234801561001057600080fd5b50600436106100b45760003560e01c8063d0e0ba9511610071578063d0e0ba9514610122578063d1ad6efe14610135578063d8b0b49914610148578063f326971614610150578063fd08921b14610159578063ff3c1a8f1461016157600080fd5b80634a79d50c146100b95780635d1ca631146100d757806372910be0146100e95780639e0c3ead146100fe578063af640d0f14610106578063bdd85ffa1461010f575b600080fd5b6100c1610169565b6040516100ce9190610368565b60405180910390f35b6000545b6040519081526020016100ce565b6100fc6100f73660046103d3565b6101f7565b005b6100c161020e565b6100db60005481565b6100fc61011d366004610484565b600355565b6100fc610130366004610484565b600055565b6100fc6101433660046103d3565b6102a0565b6100c16102b3565b6100db60035481565b6003546100db565b6100c16102c0565b600180546101769061049d565b80601f01602080910402602001604051908101604052809291908181526020018280546101a29061049d565b80156101ef5780601f106101c4576101008083540402835291602001916101ef565b820191906000526020600020905b8154815290600101906020018083116101d257829003601f168201915b505050505081565b805161020a9060019060208401906102cf565b5050565b60606002805461021d9061049d565b80601f01602080910402602001604051908101604052809291908181526020018280546102499061049d565b80156102965780601f1061026b57610100808354040283529160200191610296565b820191906000526020600020905b81548152906001019060200180831161027957829003601f168201915b5050505050905090565b805161020a9060029060208401906102cf565b600280546101769061049d565b60606001805461021d9061049d565b8280546102db9061049d565b90600052602060002090601f0160209004810192826102fd5760008555610343565b82601f1061031657805160ff1916838001178555610343565b82800160010185558215610343579182015b82811115610343578251825591602001919060010190610328565b5061034f929150610353565b5090565b5b8082111561034f5760008155600101610354565b600060208083528351808285015260005b8181101561039557858101830151858201604001528201610379565b818111156103a7576000604083870101525b50601f01601f1916929092016040019392505050565b634e487b7160e01b600052604160045260246000fd5b6000602082840312156103e557600080fd5b813567ffffffffffffffff808211156103fd57600080fd5b818401915084601f83011261041157600080fd5b813581811115610423576104236103bd565b604051601f8201601f19908116603f0116810190838211818310171561044b5761044b6103bd565b8160405282815287602084870101111561046457600080fd5b826020860160208301376000928101602001929092525095945050505050565b60006020828403121561049657600080fd5b5035919050565b600181811c908216806104b157607f821691505b602082108114156104d257634e487b7160e01b600052602260045260246000fd5b5091905056fea2646970667358221220b1583d661829057cf1857fd465abec73e485a82d067b157b349331a8661df76364736f6c634300080c0033")

contract_names.append('Role')
abis.append(json.loads('[{"inputs":[],"name":"movieId","outputs":[{"internalType":"contractMovie","name":"","type":"address"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"personId","outputs":[{"internalType":"contractPerson","name":"","type":"address"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"role","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[],"name":"getRole","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"string","name":"aRole","type":"string"}],"name":"setRole","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"getMovieId","outputs":[{"internalType":"contractMovie","name":"","type":"address"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"contractMovie","name":"aMovieId","type":"address"}],"name":"setMovieId","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"getPersonId","outputs":[{"internalType":"contractPerson","name":"","type":"address"}],"stateMutability":"view","type":"function","constant":true},{"inputs":[{"internalType":"contractPerson","name":"aPersonId","type":"address"}],"name":"setPersonId","outputs":[],"stateMutability":"nonpayable","type":"function"}]'))
bytecodes.append("0x608060405234801561001057600080fd5b50610528806100206000396000f3fe608060405234801561001057600080fd5b50600436106100935760003560e01c806386e5a12d1161006657806386e5a12d1461013d57806388e3b5751461015057806389d26294146101635780638e0cfbc214610174578063fde081741461018757600080fd5b806310055c1d1461009857806336dcabe0146100b65780636156b460146100db578063839bb1081461010d575b600080fd5b6100a061018f565b6040516100ad919061035f565b60405180910390f35b6001546001600160a01b03165b6040516001600160a01b0390911681526020016100ad565b61010b6100e93660046103cc565b600280546001600160a01b0319166001600160a01b0392909216919091179055565b005b61010b61011b3660046103cc565b600180546001600160a01b0319166001600160a01b0392909216919091179055565b6001546100c3906001600160a01b031681565b6002546100c3906001600160a01b031681565b6002546001600160a01b03166100c3565b61010b610182366004610406565b61021d565b6100a0610234565b6000805461019c906104b7565b80601f01602080910402602001604051908101604052809291908181526020018280546101c8906104b7565b80156102155780601f106101ea57610100808354040283529160200191610215565b820191906000526020600020905b8154815290600101906020018083116101f857829003601f168201915b505050505081565b80516102309060009060208401906102c6565b5050565b606060008054610243906104b7565b80601f016020809104026020016040519081016040528092919081815260200182805461026f906104b7565b80156102bc5780601f10610291576101008083540402835291602001916102bc565b820191906000526020600020905b81548152906001019060200180831161029f57829003601f168201915b5050505050905090565b8280546102d2906104b7565b90600052602060002090601f0160209004810192826102f4576000855561033a565b82601f1061030d57805160ff191683800117855561033a565b8280016001018555821561033a579182015b8281111561033a57825182559160200191906001019061031f565b5061034692915061034a565b5090565b5b80821115610346576000815560010161034b565b600060208083528351808285015260005b8181101561038c57858101830151858201604001528201610370565b8181111561039e576000604083870101525b50601f01601f1916929092016040019392505050565b6001600160a01b03811681146103c957600080fd5b50565b6000602082840312156103de57600080fd5b81356103e9816103b4565b9392505050565b634e487b7160e01b600052604160045260246000fd5b60006020828403121561041857600080fd5b813567ffffffffffffffff8082111561043057600080fd5b818401915084601f83011261044457600080fd5b813581811115610456576104566103f0565b604051601f8201601f19908116603f0116810190838211818310171561047e5761047e6103f0565b8160405282815287602084870101111561049757600080fd5b826020860160208301376000928101602001929092525095945050505050565b600181811c908216806104cb57607f821691505b602082108114156104ec57634e487b7160e01b600052602260045260246000fd5b5091905056fea2646970667358221220ac411a4b9cddd94a7635cd3404db55e0cfd092a51e82117dc2d68fbcc4a6e9d864736f6c634300080c0033")


# # set pre-funded account as sender
web3.eth.defaultAccount = web3.eth.accounts[0]

contracts = []
for c in range(num_contracts):
   contracts.append(web3.eth.contract(abi=abis[c], bytecode=bytecodes[c]))

rset = ResourceSet()
resource = rset.get_resource(URI(source_meta_model))
mm_root = resource.contents[0]
rset.metamodel_registry[mm_root.nsURI] = mm_root
resource = rset.get_resource(URI(source_model))
model_root = resource.contents[0]

num_assertion_executions = 0

def capitalize_first_letter_only(s):
    return s[0].upper() + s[1:]

def add_intance_to_blockchain(className,arguments, rootContract):
    global num_assertion_executions
    theContract_index = contract_names.index(className)
    theContract= contracts[theContract_index]

    # # Submit the transaction that instantiates the contract
    tx_hash = theContract.constructor().transact()

    # # Wait for the transaction to be mined, and get the transaction receipt
    tx_receipt = web3.eth.waitForTransactionReceipt(tx_hash)

    # # Create the contract instance with the newly-deployed address
    contract = web3.eth.contract(
        address=tx_receipt.contractAddress,
        abi=abis[theContract_index],
    )

    for argument_key in arguments.keys():
        # update the state variable
        func = contract.get_function_by_name('set'+capitalize_first_letter_only(argument_key))
        tx_hash = func(arguments[argument_key]).transact()
        web3.eth.waitForTransactionReceipt(tx_hash)
        fun = contract.functions['get'+capitalize_first_letter_only(argument_key)]       
        assert_that(fun().call()).is_equal_to(arguments[argument_key])
        num_assertion_executions = num_assertion_executions + 1

    func = rootContract.get_function_by_name('add'+capitalize_first_letter_only(className))
    tx_hash = func(contract.address).transact()
    web3.eth.waitForTransactionReceipt(tx_hash)
    return contract
        

mapping_ecore_contracts = {}

# # Submit the transaction that instantiates the contract
tx_hash = contracts[0].constructor().transact()

# # Wait for the transaction to be mined, and get the transaction receipt
tx_receipt = web3.eth.waitForTransactionReceipt(tx_hash)

# # Create the contract instance with the newly-deployed address
rootContract = web3.eth.contract(
    address=tx_receipt.contractAddress,
    abi=abis[0],
)
print("container contract address: "+rootContract.address)

n = dir(model_root)
num_entities_processed = 0

for cl in n:
    for entity in model_root.__getattribute__(cl):
        className = capitalize_first_letter_only(cl)

        atts = dir(entity)

        arguments = {}
        for att in atts:
            if type(entity.__getattribute__(att)) in [int,str]:
                arguments[att]=entity.__getattribute__(att)
        mapping_ecore_contracts[entity] = add_intance_to_blockchain(className,arguments,rootContract)
        num_entities_processed = num_entities_processed + 1
        print(str(num_entities_processed)+' '+className)



def edit_intance(theContract,arguments):
    global num_assertion_executions
    for argument_key in arguments.keys():
        # update the state variable
        func = theContract.get_function_by_name('set'+capitalize_first_letter_only(argument_key))
        tx_hash = func(mapping_ecore_contracts[arguments[argument_key]].address).transact()
        web3.eth.waitForTransactionReceipt(tx_hash)
        fun = theContract.functions['get'+capitalize_first_letter_only(argument_key)]
        assert_that(fun().call()).is_equal_to(mapping_ecore_contracts[arguments[argument_key]].address)
        num_assertion_executions = num_assertion_executions + 1

n = dir(model_root)
for cl in n:
    for entity in model_root.__getattribute__(cl):
        className = capitalize_first_letter_only(cl)
        atts = dir(entity)
        arguments = {}
        for att in atts:
            if not type(entity.__getattribute__(att)) in [int,str]:
                arguments[att]=entity.__getattribute__(att)
        if arguments:
            edit_intance(mapping_ecore_contracts[entity],arguments)

print('---DONE---')
print('num_assertion_executions: '+ str(num_assertion_executions))

                    