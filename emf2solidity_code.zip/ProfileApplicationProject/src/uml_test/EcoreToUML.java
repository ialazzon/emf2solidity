package uml_test;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.URIConverter;
import org.eclipse.emf.ecore.resource.impl.ExtensibleURIConverterImpl;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
//import org.eclipse.emf.ecore.resource.impl.ResourceFactoryImpl;
import org.eclipse.emf.ecore.xmi.impl.EcoreResourceFactoryImpl;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.impl.EPackageImpl;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.*;
import org.eclipse.emf.ecore.impl.*;
import org.eclipse.uml2.uml.*;
import org.eclipse.uml2.uml.Class;
import org.eclipse.uml2.uml.Package;
import org.eclipse.uml2.uml.resource.UMLResource;
import org.eclipse.uml2.uml.resources.util.UMLResourcesUtil;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.uml2.uml.internal.impl.ClassImpl;
import org.eclipse.uml2.uml.internal.impl.PrimitiveTypeImpl;

import java.io.IOException;
import java.util.Collections;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.HashMap;


public class EcoreToUML {
	private static final ResourceSet RESOURCE_SET;
	private final ResourceSet set_uml;
	private final ResourceSet set_ecore;
    private static final ExtensibleURIConverterImpl converter = new ExtensibleURIConverterImpl();
    private static final URI ulProfile = URI.createURI("contracts.profile.profile.uml");
    private static final URI upProfile = URI.createFileURI("contracts.profile.uml");
    
    static {
		RESOURCE_SET = new ResourceSetImpl();
		UMLResourcesUtil.init(RESOURCE_SET);

		converter.getURIMap().put(ulProfile, upProfile);
	}
    
    public EcoreToUML() throws IOException {
    	set_ecore = new ResourceSetImpl();
        set_ecore.getPackageRegistry().put(EcorePackage.eNS_URI, EcorePackage.eINSTANCE);
        set_ecore.getResourceFactoryRegistry().getExtensionToFactoryMap()
                .put("ecore", new EcoreResourceFactoryImpl());

        
    	set_uml = new ResourceSetImpl();
        set_uml.getPackageRegistry().put(UMLPackage.eNS_URI, UMLPackage.eINSTANCE);
        set_uml.getResourceFactoryRegistry().getExtensionToFactoryMap()
                .put(UMLResource.FILE_EXTENSION, UMLResource.Factory.INSTANCE);
        Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap()
                .put(UMLResource.FILE_EXTENSION, UMLResource.Factory.INSTANCE);
    }
	
	public Profile eMFLoadProfile() throws IOException {
		
		Resource res = set_uml.getResource(URI.createFileURI("contracts.profile.uml"), true);
		Profile profile = (Profile)RESOURCE_SET.getResource(converter.normalize(ulProfile), true).getContents().get(0);
		profile.define();

		return profile;	
	}
	
	public void eMFLoadAndApplyProfile(Profile p) throws IOException {	
		Resource res_ecore = set_ecore.getResource(URI.createFileURI("personsMovies.ecore"), true);
		EPackageImpl r = (EPackageImpl)(res_ecore.getContents().get(0));
		Resource resM = set_uml.createResource(URI.createFileURI("personsMovies_with_profile.uml"));
		Model model = UMLFactory.eINSTANCE.createModel();
		model.setName(r.getName());
		Model umlLibrary = (Model) set_uml.getResource(URI.createURI(UMLResource.UML_PRIMITIVE_TYPES_LIBRARY_URI), true).getContents().get(0);
		HashMap<String,Class> the_map = new HashMap<>();//maps from class name to the corresponding uml class instance
		HashMap<String,String> the_map2 = new HashMap<>();//maps from reference name e.g. Book:authors to the corresponding type's name e.f. Person
		
		for(EClassifier c: r.getEClassifiers()) {
			EClassImpl cl = (EClassImpl)c;
			model.createOwnedClass(cl.getName(), false);
			Class uml_cl = (Class)(model.getOwnedMembers().get(model.getOwnedMembers().size()-1));
			the_map.put(cl.getName(),uml_cl);
			
			for(EObject eo: c.eContents()) {
				EStructuralFeatureImpl fe = (EStructuralFeatureImpl)eo;
				if(fe instanceof EAttributeImpl) {
					switch(fe.getEType().getName()) {
						case "EString": uml_cl.createOwnedAttribute(fe.getName(), umlLibrary.getOwnedType("String")); break;
						case "EInt": uml_cl.createOwnedAttribute(fe.getName(), umlLibrary.getOwnedType("Integer")); break;
						case "EDouble": uml_cl.createOwnedAttribute(fe.getName(), umlLibrary.getOwnedType("Real")); break;
						case "EBoolean": uml_cl.createOwnedAttribute(fe.getName(), umlLibrary.getOwnedType("Boolean")); break;
					}
				}else{/* EReferenceImpl */

					uml_cl.createOwnedAttribute(fe.getName(), null);
					Property pr = uml_cl.getOwnedAttribute(fe.getName(), null);
					the_map2.put(cl.getName()+":"+fe.getName(), ((EReferenceImpl)fe).getEReferenceType().getName());
					pr.setLower(((EReferenceImpl)fe).getLowerBound());
					pr.setUpper(((EReferenceImpl)fe).getUpperBound());
				}

			}	
		}
		/* Second Pass */
		for(EObject eo:model.eContents()) {
			Class cl = (Class)eo;
			for(EObject pro:cl.eContents()) {
				Property pr = (Property)pro;
				
				if(pr.getType()==null) {
					pr.setType(the_map.get(the_map2.get(cl.getName()+":"+pr.getName())));
				}
				
			}
		}
		
		model.applyProfile(p);
		resM.getContents().add(model);
		for(PackageableElement pe: model.getPackagedElements()) {
			Class cl = (Class)(pe);
			System.out.println("Class: "+cl.getName());
			Stereotype st = p.getOwnedStereotype("Contract");
			cl.applyStereotype(st);
			
			for(Property pr :cl.getAllAttributes()) {
				System.out.println("Property: "+pr.getName());
				st = p.getOwnedStereotype("GetterSetter");
				pr.applyStereotype(st);
			}
		}

		 resM.save(Collections.EMPTY_MAP);
		 System.out.println("Done");
	}
	

	
	public static void main(String args[]) throws IOException {
		EcoreToUML pa = new EcoreToUML();
		Profile p = pa.eMFLoadProfile();
		pa.eMFLoadAndApplyProfile(p);
	}
	

}

